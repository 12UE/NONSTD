#pragma once
#include<Windows.h>
//#include<ntdef.h>
#include<winerror.h>
#include"_nonstdInt.h"
#include<errno.h>
namespace nonstd {

#define DbgPrint printf
}

#pragma once
namespace nonstd {
   using _Literal_zero = decltype(nullptr);
   using _Compare_t = signed char;

   // These "pretty" enumerator names are safe since they reuse names of user-facing entities.
   enum class _Compare_eq : _Compare_t { equal = 0, equivalent = equal };
   enum class _Compare_ord : _Compare_t { less = -1, greater = 1 };
   enum class _Compare_ncmp : _Compare_t { unordered = -128 };

   struct partial_ordering {
       static const partial_ordering less;
       static const partial_ordering equivalent;
       static const partial_ordering greater;
       static const partial_ordering unordered;

       _NODISCARD friend constexpr bool operator==(const partial_ordering _Val, _Literal_zero) noexcept {
           return _Val._Value == 0;
       }

       _NODISCARD friend constexpr bool operator==(partial_ordering, partial_ordering) noexcept = default;

       _NODISCARD friend constexpr bool operator<(const partial_ordering _Val, _Literal_zero) noexcept {
           return _Val._Value == static_cast<_Compare_t>(_Compare_ord::less);
       }

       _NODISCARD friend constexpr bool operator>(const partial_ordering _Val, _Literal_zero) noexcept {
           return _Val._Value > 0;
       }

       _NODISCARD friend constexpr bool operator<=(const partial_ordering _Val, _Literal_zero) noexcept {
           // The stored value is either less (0xff), equivalent (0x00), greater (0x01), or unordered (0x80).
           // Subtracting from 0 produces either 0x01, 0x00, 0xff, or 0x80. The result is greater than or equal to 0
           // if and only if the initial value was less or equivalent, for which we want to return true.
           return static_cast<signed char>(0 - static_cast<unsigned int>(_Val._Value)) >= 0;
       }

       _NODISCARD friend constexpr bool operator>=(const partial_ordering _Val, _Literal_zero) noexcept {
           return _Val._Value >= 0;
       }

       _NODISCARD friend constexpr bool operator<(_Literal_zero, const partial_ordering _Val) noexcept {
           return _Val > 0;
       }

       _NODISCARD friend constexpr bool operator>(_Literal_zero, const partial_ordering _Val) noexcept {
           return _Val < 0;
       }

       _NODISCARD friend constexpr bool operator<=(_Literal_zero, const partial_ordering _Val) noexcept {
           return _Val >= 0;
       }

       _NODISCARD friend constexpr bool operator>=(_Literal_zero, const partial_ordering _Val) noexcept {
           return _Val <= 0;
       }

       _NODISCARD friend constexpr partial_ordering operator<=>(const partial_ordering _Val, _Literal_zero) noexcept {
           return _Val;
       }

       _NODISCARD friend constexpr partial_ordering operator<=>(_Literal_zero, const partial_ordering _Val) noexcept {
           // The stored value is either less (0xff), equivalent (0x00), greater (0x01), or unordered (0x80).
           // Subtracting from 0 produces either 0x01, 0x00, 0xff, or 0x80. Note that the effect is to
           // exchange less for greater (and vice versa), while leaving equivalent and unordered unchanged.
           return { static_cast<_Compare_t>(0 - static_cast<unsigned int>(_Val._Value)) };
       }

       _Compare_t _Value;
   };

   inline constexpr partial_ordering partial_ordering::less{ static_cast<_Compare_t>(_Compare_ord::less) };
   inline constexpr partial_ordering partial_ordering::equivalent{ static_cast<_Compare_t>(_Compare_eq::equivalent) };
   inline constexpr partial_ordering partial_ordering::greater{ static_cast<_Compare_t>(_Compare_ord::greater) };
   inline constexpr partial_ordering partial_ordering::unordered{ static_cast<_Compare_t>(_Compare_ncmp::unordered) };

   struct weak_ordering {
       static const weak_ordering less;
       static const weak_ordering equivalent;
       static const weak_ordering greater;

       constexpr operator partial_ordering() const noexcept {
           return { static_cast<_Compare_t>(_Value) };
       }

       _NODISCARD friend constexpr bool operator==(const weak_ordering _Val, _Literal_zero) noexcept {
           return _Val._Value == 0;
       }

       _NODISCARD friend constexpr bool operator==(weak_ordering, weak_ordering) noexcept = default;

       _NODISCARD friend constexpr bool operator<(const weak_ordering _Val, _Literal_zero) noexcept {
           return _Val._Value < 0;
       }

       _NODISCARD friend constexpr bool operator>(const weak_ordering _Val, _Literal_zero) noexcept {
           return _Val._Value > 0;
       }

       _NODISCARD friend constexpr bool operator<=(const weak_ordering _Val, _Literal_zero) noexcept {
           return _Val._Value <= 0;
       }

       _NODISCARD friend constexpr bool operator>=(const weak_ordering _Val, _Literal_zero) noexcept {
           return _Val._Value >= 0;
       }

       _NODISCARD friend constexpr bool operator<(_Literal_zero, const weak_ordering _Val) noexcept {
           return _Val > 0;
       }

       _NODISCARD friend constexpr bool operator>(_Literal_zero, const weak_ordering _Val) noexcept {
           return _Val < 0;
       }

       _NODISCARD friend constexpr bool operator<=(_Literal_zero, const weak_ordering _Val) noexcept {
           return _Val >= 0;
       }

       _NODISCARD friend constexpr bool operator>=(_Literal_zero, const weak_ordering _Val) noexcept {
           return _Val <= 0;
       }

       _NODISCARD friend constexpr weak_ordering operator<=>(const weak_ordering _Val, _Literal_zero) noexcept {
           return _Val;
       }

       _NODISCARD friend constexpr weak_ordering operator<=>(_Literal_zero, const weak_ordering _Val) noexcept {
           return { static_cast<_Compare_t>(-_Val._Value) };
       }

       _Compare_t _Value;
   };

   inline constexpr weak_ordering weak_ordering::less{ static_cast<_Compare_t>(_Compare_ord::less) };
   inline constexpr weak_ordering weak_ordering::equivalent{ static_cast<_Compare_t>(_Compare_eq::equivalent) };
   inline constexpr weak_ordering weak_ordering::greater{ static_cast<_Compare_t>(_Compare_ord::greater) };

   struct strong_ordering {
       static const strong_ordering less;
       static const strong_ordering equal;
       static const strong_ordering equivalent;
       static const strong_ordering greater;

       constexpr operator partial_ordering() const noexcept {
           return { static_cast<_Compare_t>(_Value) };
       }

       constexpr operator weak_ordering() const noexcept {
           return { static_cast<_Compare_t>(_Value) };
       }

       _NODISCARD friend constexpr bool operator==(const strong_ordering _Val, _Literal_zero) noexcept {
           return _Val._Value == 0;
       }

       _NODISCARD friend constexpr bool operator==(strong_ordering, strong_ordering) noexcept = default;

       _NODISCARD friend constexpr bool operator<(const strong_ordering _Val, _Literal_zero) noexcept {
           return _Val._Value < 0;
       }

       _NODISCARD friend constexpr bool operator>(const strong_ordering _Val, _Literal_zero) noexcept {
           return _Val._Value > 0;
       }

       _NODISCARD friend constexpr bool operator<=(const strong_ordering _Val, _Literal_zero) noexcept {
           return _Val._Value <= 0;
       }

       _NODISCARD friend constexpr bool operator>=(const strong_ordering _Val, _Literal_zero) noexcept {
           return _Val._Value >= 0;
       }

       _NODISCARD friend constexpr bool operator<(_Literal_zero, const strong_ordering _Val) noexcept {
           return _Val > 0;
       }

       _NODISCARD friend constexpr bool operator>(_Literal_zero, const strong_ordering _Val) noexcept {
           return _Val < 0;
       }

       _NODISCARD friend constexpr bool operator<=(_Literal_zero, const strong_ordering _Val) noexcept {
           return _Val >= 0;
       }

       _NODISCARD friend constexpr bool operator>=(_Literal_zero, const strong_ordering _Val) noexcept {
           return _Val <= 0;
       }

       _NODISCARD friend constexpr strong_ordering operator<=>(const strong_ordering _Val, _Literal_zero) noexcept {
           return _Val;
       }

       _NODISCARD friend constexpr strong_ordering operator<=>(_Literal_zero, const strong_ordering _Val) noexcept {
           return { static_cast<_Compare_t>(-_Val._Value) };
       }

       _Compare_t _Value;
   };

   inline constexpr strong_ordering strong_ordering::less{ static_cast<_Compare_t>(_Compare_ord::less) };
   inline constexpr strong_ordering strong_ordering::equal{ static_cast<_Compare_t>(_Compare_eq::equal) };
   inline constexpr strong_ordering strong_ordering::equivalent{ static_cast<_Compare_t>(_Compare_eq::equivalent) };
   inline constexpr strong_ordering strong_ordering::greater{ static_cast<_Compare_t>(_Compare_ord::greater) };

   _NODISCARD constexpr bool is_eq(const partial_ordering _Comp) noexcept {
       return _Comp == 0;
   }

   _NODISCARD constexpr bool is_neq(const partial_ordering _Comp) noexcept {
       return _Comp != 0;
   }

   _NODISCARD constexpr bool is_lt(const partial_ordering _Comp) noexcept {
       return _Comp < 0;
   }

   _NODISCARD constexpr bool is_lteq(const partial_ordering _Comp) noexcept {
       return _Comp <= 0;
   }

   _NODISCARD constexpr bool is_gt(const partial_ordering _Comp) noexcept {
       return _Comp > 0;
   }

   _NODISCARD constexpr bool is_gteq(const partial_ordering _Comp) noexcept {
       return _Comp >= 0;
   }

   enum _Comparison_category : unsigned char {
       _Comparison_category_none = 1,
       _Comparison_category_partial = 2,
       _Comparison_category_weak = 4,
       _Comparison_category_strong = 0,
   };

   template <class... _Types>
   inline constexpr unsigned char _Classify_category =
       _Comparison_category{ (_Classify_category<_Types> | ... | _Comparison_category_strong) };
   template <class _Ty>
   inline constexpr unsigned char _Classify_category<_Ty> = _Comparison_category_none;
   template <>
   inline constexpr unsigned char _Classify_category<partial_ordering> = _Comparison_category_partial;
   template <>
   inline constexpr unsigned char _Classify_category<weak_ordering> = _Comparison_category_weak;
   template <>
   inline constexpr unsigned char _Classify_category<strong_ordering> = _Comparison_category_strong;

   template <class... _Types>
   using common_comparison_category_t =
       conditional_t<(_Classify_category<_Types...>& _Comparison_category_none) != 0, void,
       conditional_t<(_Classify_category<_Types...>& _Comparison_category_partial) != 0, partial_ordering,
       conditional_t<(_Classify_category<_Types...>& _Comparison_category_weak) != 0, weak_ordering,
       strong_ordering>>>;

   template <class... _Types>
   struct common_comparison_category {
       using type = common_comparison_category_t<_Types...>;
   };
   template <class _Ty>
   struct _Choice_t {
       _Ty _Strategy = _Ty{};
       bool _No_throw = false;
   };
   template <class _Ty1, class _Ty2>
   concept _Same_impl = // Must be a distinct concept to provide symmetric subsumption for same_as
#ifdef __clang__
       __is_same(_Ty1, _Ty2);
#else // ^^^ use intrinsic / no intrinsic vvv
       is_same_v<_Ty1, _Ty2>;
#endif // __clang__

   template <class _Ty1, class _Ty2>
   concept same_as = _Same_impl<_Ty1, _Ty2> && _Same_impl<_Ty2, _Ty1>;
   // clang-format off
   template <class _Ty, class _Cat>
   concept _Compares_as = same_as<common_comparison_category_t<_Ty, _Cat>, _Cat>;
   template <class _Ty>
   concept _Boolean_testable_impl = __is_convertible_to(_Ty, bool);

   template <class _Ty>
   concept _Boolean_testable = _Boolean_testable_impl<_Ty>
       && requires(_Ty && __t) {
           { !static_cast<_Ty&&>(__t) } -> _Boolean_testable_impl;
   };

   template <class _Ty1, class _Ty2>
   concept _Half_equality_comparable =
       requires(const remove_reference_t<_Ty1>&__x, const remove_reference_t<_Ty2>&__y) {
           { __x == __y } -> _Boolean_testable;
           { __x != __y } -> _Boolean_testable;
   };
   template <class _Ty1, class _Ty2>
   concept _Half_ordered = requires(const remove_reference_t<_Ty1>&__t, const remove_reference_t<_Ty2>&__u) {
       { __t < __u } -> _Boolean_testable;
       { __t > __u } -> _Boolean_testable;
       { __t <= __u } -> _Boolean_testable;
       { __t >= __u } -> _Boolean_testable;
   };

   template <class _Ty1, class _Ty2>
   concept _Partially_ordered_with = _Half_ordered<_Ty1, _Ty2> && _Half_ordered<_Ty2, _Ty1>;
   
   template <class _Ty, class _Cat = partial_ordering>
   concept three_way_comparable = _Half_equality_comparable<_Ty, _Ty> && _Half_ordered<_Ty, _Ty>
       && requires(const remove_reference_t<_Ty>&__a, const remove_reference_t<_Ty>&__b) {
           { __a <=> __b } -> _Compares_as<_Cat>;
   };
   
   
   template <class _Ty1, class _Ty2>
   concept common_reference_with =
       requires {
       typename common_reference_t<_Ty1, _Ty2>;
       typename common_reference_t<_Ty2, _Ty1>;
   }
   && same_as<common_reference_t<_Ty1, _Ty2>, common_reference_t<_Ty2, _Ty1>>
       && is_convertible_v<_Ty1, common_reference_t<_Ty1, _Ty2>>
       && is_convertible_v<_Ty2, common_reference_t<_Ty1, _Ty2>>;
   
   //template <class _Ty1, class _Ty2>
   //concept _Half_equality_comparable =requires(const remove_reference_t<_Ty1>&__x, const remove_reference_t<_Ty2>&__y) {
   //        { __x == __y } -> _Boolean_testable;
   //        { __x != __y } -> _Boolean_testable;
   //};

   template <class _Ty1, class _Ty2>
   concept _Weakly_equality_comparable_with =_Half_equality_comparable<_Ty1, _Ty2> && _Half_equality_comparable<_Ty2, _Ty1>;
   
   template <class _Ty1, class _Ty2, class _Cat = partial_ordering>
   concept three_way_comparable_with = three_way_comparable<_Ty1, _Cat> && three_way_comparable<_Ty2, _Cat>
       && common_reference_with<const remove_reference_t<_Ty1>&, const remove_reference_t<_Ty2>&>
       && three_way_comparable<common_reference_t<const remove_reference_t<_Ty1>&, const remove_reference_t<_Ty2>&>, _Cat>
       && _Weakly_equality_comparable_with<_Ty1, _Ty2> && _Partially_ordered_with<_Ty1, _Ty2>
       && requires(const remove_reference_t<_Ty1>&__t, const remove_reference_t<_Ty2>&__u) {
           { __t <=> __u } -> _Compares_as<_Cat>;
           { __u <=> __t } -> _Compares_as<_Cat>;
   };

   template <class _Ty1, class _Ty2 = _Ty1>
   using compare_three_way_result_t =
       decltype(nonstd:: declval<const remove_reference_t<_Ty1>&>() <=> nonstd:: declval<const remove_reference_t<_Ty2>&>());

   template <class _Ty1, class _Ty2 = _Ty1>
   struct compare_three_way_result {};

   template <class _Ty1, class _Ty2>
       requires requires { typename compare_three_way_result_t<_Ty1, _Ty2>; }
   struct compare_three_way_result<_Ty1, _Ty2> {
       using type = compare_three_way_result_t<_Ty1, _Ty2>;
   };

   struct compare_three_way {
       template <class _Ty1, class _Ty2>
           requires three_way_comparable_with<_Ty1, _Ty2>
       _NODISCARD constexpr auto operator()(_Ty1&& _Left, _Ty2&& _Right) const
           noexcept(noexcept(nonstd:: forward<_Ty1>(_Left) <=> nonstd:: forward<_Ty2>(_Right))) /* strengthened */ {
           return nonstd:: forward<_Ty1>(_Left) <=> nonstd:: forward<_Ty2>(_Right);
       }

       using is_transparent = int;
   };
   // clang-format on

   struct _Synth_three_way {
       // clang-format off
       template <class _Ty1, class _Ty2>
       _NODISCARD constexpr auto operator()(const _Ty1& _Left, const _Ty2& _Right) const
           requires requires {
               { _Left < _Right } -> _Boolean_testable;
               { _Right < _Left } -> _Boolean_testable;
       }
       // clang-format on
       {
           if constexpr (three_way_comparable_with<_Ty1, _Ty2>) {
               return _Left <=> _Right;
           }
           else {
               if (_Left < _Right) {
                   return weak_ordering::less;
               }
               else if (_Right < _Left) {
                   return weak_ordering::greater;
               }
               else {
                   return weak_ordering::equivalent;
               }
           }
       }
   };

   template <class _Ty1, class _Ty2 = _Ty1>
   using _Synth_three_way_result = decltype(_Synth_three_way{}(nonstd:: declval<_Ty1&>(), nonstd:: declval<_Ty2&>()));

   // Note: The following CPOs are passing arguments as lvalues; see GH-1374.

   namespace _Strong_order {
       void strong_order(); // Block unqualified name lookup; see GH-1374.

       template <class _Ty1, class _Ty2>
       concept _Has_ADL = requires(_Ty1 & _Left, _Ty2 & _Right) {
           static_cast<strong_ordering>(/* ADL */ strong_order(_Left, _Right));
       };

       template <class _Ty1, class _Ty2>
       concept _Can_compare_three_way = requires(_Ty1 & _Left, _Ty2 & _Right) {
           static_cast<strong_ordering>(compare_three_way{}(_Left, _Right));
       };

       class _Cpo {
       private:
           enum class _St { _None, _Adl, _Floating, _Three };

           template <class _Ty1, class _Ty2>
           _NODISCARD static _CONSTEVAL _Choice_t<_St> _Choose() noexcept {
               if constexpr (!same_as<decay_t<_Ty1>, decay_t<_Ty2>>) {
                   return { _St::_None };
               }
               else if constexpr (_Has_ADL<_Ty1, _Ty2>) {
                   return { _St::_Adl, noexcept(static_cast<strong_ordering>(
                       /* ADL */ strong_order(nonstd:: declval<_Ty1&>(), nonstd:: declval<_Ty2&>()))) };
               }
               else if constexpr (floating_point<decay_t<_Ty1>>) {
                   return { _St::_Floating, true };
               }
               else if constexpr (_Can_compare_three_way<_Ty1, _Ty2>) {
                   return { _St::_Three, noexcept(static_cast<strong_ordering>(
                                            compare_three_way{}(nonstd:: declval<_Ty1&>(), nonstd:: declval<_Ty2&>()))) };
               }
               else {
                   return { _St::_None };
               }
           }

           template <class _Ty1, class _Ty2>
           static constexpr _Choice_t<_St> _Choice = _Choose<_Ty1, _Ty2>();

       public:
           // clang-format off
           template <class _Ty1, class _Ty2>
               requires (_Choice<_Ty1&, _Ty2&>._Strategy != _St::_None)
           _NODISCARD constexpr strong_ordering operator()(_Ty1&& _Left, _Ty2&& _Right) const
               noexcept(_Choice<_Ty1&, _Ty2&>._No_throw) {
               // clang-format on
               constexpr _St _Strat = _Choice<_Ty1&, _Ty2&>._Strategy;
               if constexpr (_Strat == _St::_Adl) {
                   return static_cast<strong_ordering>(/* ADL */ strong_order(_Left, _Right));
               }
               else if constexpr (_Strat == _St::_Floating) {
                   using _Floating_type = decay_t<_Ty1>;
                   using _Traits = _Floating_type_traits<_Floating_type>;
                   using _Uint_type = typename _Traits::_Uint_type;
                   using _Sint_type = make_signed_t<_Uint_type>;

                   const auto _Left_uint = __builtin_bit_cast(_Uint_type,_Left);
                   const auto _Right_uint = __builtin_bit_cast(_Uint_type,_Right);

                   // 1. Ultra-fast path: equal representations are equal.
                   if (_Left_uint == _Right_uint) {
                       return strong_ordering::equal;
                   }

                   // 2. Examine the sign bits.
                   const _Uint_type _Left_shifted_sign = _Left_uint & _Traits::_Shifted_sign_mask;
                   const _Uint_type _Right_shifted_sign = _Right_uint & _Traits::_Shifted_sign_mask;

                   // 3. Interpret floating-point bit patterns as sign magnitude representations of integers,
                   //    and then transform them into ones' complement representation.
                   // (Ones' complement representations of positive zero and negative zero are different.)
                   const _Uint_type _Left_sign = _Left_shifted_sign >> _Traits::_Sign_shift;
                   const _Uint_type _Right_sign = _Right_shifted_sign >> _Traits::_Sign_shift;

                   const _Uint_type _Left_xor = _Left_shifted_sign - _Left_sign;
                   const _Uint_type _Right_xor = _Right_shifted_sign - _Right_sign;

                   const _Uint_type _Left_ones_complement_uint = _Left_uint ^ _Left_xor;
                   const _Uint_type _Right_ones_complement_uint = _Right_uint ^ _Right_xor;

                   const auto _Left_ones_complement = static_cast<_Sint_type>(_Left_ones_complement_uint);
                   const auto _Right_ones_complement = static_cast<_Sint_type>(_Right_ones_complement_uint);

                   // 4. Perform the final comparison.
                   return _Left_ones_complement <=> _Right_ones_complement;
               }
               else if constexpr (_Strat == _St::_Three) {
                   return static_cast<strong_ordering>(compare_three_way{}(_Left, _Right));
               }
               else {
                   static_assert(_Always_false<_Ty1>, "should be unreachable");
               }
           }
       };
   } // namespace _Strong_order

   inline namespace _Cpos {
       inline constexpr _Strong_order::_Cpo strong_order;
   }

   namespace _Weak_order {
       void weak_order(); // Block unqualified name lookup; see GH-1374.

       template <class _Ty1, class _Ty2>
       concept _Has_ADL = requires(_Ty1 & _Left, _Ty2 & _Right) {
           static_cast<weak_ordering>(/* ADL */ weak_order(_Left, _Right));
       };

       template <class _Ty1, class _Ty2>
       concept _Can_compare_three_way = requires(_Ty1 & _Left, _Ty2 & _Right) {
           static_cast<weak_ordering>(compare_three_way{}(_Left, _Right));
       };

       // Throughput optimization: attempting to use nonstd:: strong_order will always select ADL strong_order here.
       void strong_order(); // Block unqualified name lookup; see GH-1374.

       class _Cpo {
       private:
           enum class _St { _None, _Adl, _Floating, _Three, _Strong };

           template <class _Ty1, class _Ty2>
           _NODISCARD static _CONSTEVAL _Choice_t<_St> _Choose() noexcept {
               if constexpr (!same_as<decay_t<_Ty1>, decay_t<_Ty2>>) {
                   return { _St::_None };
               }
               else if constexpr (_Has_ADL<_Ty1, _Ty2>) {
                   return { _St::_Adl, noexcept(static_cast<weak_ordering>(
                       /* ADL */ weak_order(nonstd:: declval<_Ty1&>(), nonstd:: declval<_Ty2&>()))) };
               }
               else if constexpr (floating_point<decay_t<_Ty1>>) {
                   return { _St::_Floating, true };
               }
               else if constexpr (_Can_compare_three_way<_Ty1, _Ty2>) {
                   return { _St::_Three, noexcept(static_cast<weak_ordering>(
                                            compare_three_way{}(nonstd:: declval<_Ty1&>(), nonstd:: declval<_Ty2&>()))) };
               }
               else if constexpr (_Strong_order::_Has_ADL<_Ty1, _Ty2>) {
                   return { _St::_Strong, noexcept(static_cast<weak_ordering>(static_cast<strong_ordering>(
                       /* ADL, throughput optimization */ strong_order(
                           nonstd:: declval<_Ty1&>(), nonstd:: declval<_Ty2&>())))) };
               }
               else {
                   return { _St::_None };
               }
           }

           template <class _Ty1, class _Ty2>
           static constexpr _Choice_t<_St> _Choice = _Choose<_Ty1, _Ty2>();

       public:
           // clang-format off
           template <class _Ty1, class _Ty2>
               requires (_Choice<_Ty1&, _Ty2&>._Strategy != _St::_None)
           _NODISCARD constexpr weak_ordering operator()(_Ty1&& _Left, _Ty2&& _Right) const
               noexcept(_Choice<_Ty1&, _Ty2&>._No_throw) {
               // clang-format on
               constexpr _St _Strat = _Choice<_Ty1&, _Ty2&>._Strategy;
               if constexpr (_Strat == _St::_Adl) {
                   return static_cast<weak_ordering>(/* ADL */ weak_order(_Left, _Right));
               }
               else if constexpr (_Strat == _St::_Floating) {
                   using _Floating_type = decay_t<_Ty1>;
                   using _Traits = _Floating_type_traits<_Floating_type>;
                   using _Uint_type = typename _Traits::_Uint_type;
                   using _Sint_type = make_signed_t<_Uint_type>;

                   auto _Left_uint = __builtin_bit_cast(_Uint_type,_Left);
                   auto _Right_uint = __builtin_bit_cast(_Uint_type,_Right);

                   // 1. Ultra-fast path: equal representations are equivalent.
                   if (_Left_uint == _Right_uint) {
                       return weak_ordering::equivalent;
                   }

                   // 2. Examine the sign bits.
                   const _Uint_type _Left_shifted_sign = _Left_uint & _Traits::_Shifted_sign_mask;
                   const _Uint_type _Right_shifted_sign = _Right_uint & _Traits::_Shifted_sign_mask;

                   // 3. Fold all NaN values together.
                   // (The fact that _Infinity_plus_one represents a signaling NaN is irrelevant here.)
                   constexpr _Uint_type _Infinity_plus_one = _Traits::_Shifted_exponent_mask + 1;

                   const _Uint_type _Left_magnitude = _Left_uint & ~_Traits::_Shifted_sign_mask;
                   const _Uint_type _Right_magnitude = _Right_uint & ~_Traits::_Shifted_sign_mask;

                   if (_Left_magnitude > _Infinity_plus_one) {
                       _Left_uint = _Left_shifted_sign | _Infinity_plus_one;
                   }

                   if (_Right_magnitude > _Infinity_plus_one) {
                       _Right_uint = _Right_shifted_sign | _Infinity_plus_one;
                   }

                   // 4. Interpret floating-point bit patterns as sign magnitude representations of integers,
                   //    and then transform them into two's complement representation.
                   // (Two's complement representations of positive zero and negative zero are the same.)
                   const _Uint_type _Left_sign = _Left_shifted_sign >> _Traits::_Sign_shift;
                   const _Uint_type _Right_sign = _Right_shifted_sign >> _Traits::_Sign_shift;

                   const _Uint_type _Left_xor = _Left_shifted_sign - _Left_sign;
                   const _Uint_type _Right_xor = _Right_shifted_sign - _Right_sign;

                   const _Uint_type _Left_twos_complement_uint = (_Left_uint ^ _Left_xor) + _Left_sign;
                   const _Uint_type _Right_twos_complement_uint = (_Right_uint ^ _Right_xor) + _Right_sign;

                   const auto _Left_twos_complement = static_cast<_Sint_type>(_Left_twos_complement_uint);
                   const auto _Right_twos_complement = static_cast<_Sint_type>(_Right_twos_complement_uint);

                   // 5. Perform the final comparison.
                   return static_cast<weak_ordering>(_Left_twos_complement <=> _Right_twos_complement);
               }
               else if constexpr (_Strat == _St::_Three) {
                   return static_cast<weak_ordering>(compare_three_way{}(_Left, _Right));
               }
               else if constexpr (_Strat == _St::_Strong) {
                   return static_cast<weak_ordering>(
                       static_cast<strong_ordering>(/* ADL, throughput optimization */ strong_order(_Left, _Right)));
               }
               else {
                   static_assert(_Always_false<_Ty1>, "should be unreachable");
               }
           }
       };
   } // namespace _Weak_order

   inline namespace _Cpos {
       inline constexpr _Weak_order::_Cpo weak_order;
   }

   namespace _Partial_order {
       void partial_order(); // Block unqualified name lookup; see GH-1374.

       template <class _Ty1, class _Ty2>
       concept _Has_ADL = requires(_Ty1 & _Left, _Ty2 & _Right) {
           static_cast<partial_ordering>(/* ADL */ partial_order(_Left, _Right));
       };

       template <class _Ty1, class _Ty2>
       concept _Can_compare_three_way = requires(_Ty1 & _Left, _Ty2 & _Right) {
           static_cast<partial_ordering>(compare_three_way{}(_Left, _Right));
       };

       // Throughput optimization: attempting to use nonstd:: weak_order
       // will attempt to select ADL weak_order, followed by ADL strong_order, here.
       void weak_order(); // Block unqualified name lookup; see GH-1374.
       void strong_order(); // Block unqualified name lookup; see GH-1374.

       class _Cpo {
       private:
           enum class _St { _None, _Adl, _Three, _Weak, _Strong };

           template <class _Ty1, class _Ty2>
           _NODISCARD static _CONSTEVAL _Choice_t<_St> _Choose() noexcept {
               if constexpr (!same_as<decay_t<_Ty1>, decay_t<_Ty2>>) {
                   return { _St::_None };
               }
               else if constexpr (_Has_ADL<_Ty1, _Ty2>) {
                   return { _St::_Adl, noexcept(static_cast<partial_ordering>(
                       /* ADL */ partial_order(nonstd:: declval<_Ty1&>(), nonstd:: declval<_Ty2&>()))) };
               }
               else if constexpr (_Can_compare_three_way<_Ty1, _Ty2>) {
                   return { _St::_Three, noexcept(static_cast<partial_ordering>(
                                            compare_three_way{}(nonstd:: declval<_Ty1&>(), nonstd:: declval<_Ty2&>()))) };
               }
               else if constexpr (_Weak_order::_Has_ADL<_Ty1, _Ty2>) {
                   return { _St::_Weak,
                       noexcept(static_cast<partial_ordering>(static_cast<weak_ordering>(
                           /* ADL, throughput optimization */ weak_order(nonstd:: declval<_Ty1&>(), nonstd:: declval<_Ty2&>())))) };
               }
               else if constexpr (_Strong_order::_Has_ADL<_Ty1, _Ty2>) {
                   return { _St::_Strong, noexcept(static_cast<partial_ordering>(static_cast<strong_ordering>(
                       /* ADL, throughput optimization */ strong_order(
                           nonstd:: declval<_Ty1&>(), nonstd:: declval<_Ty2&>())))) };
               }
               else {
                   return { _St::_None };
               }
           }

           template <class _Ty1, class _Ty2>
           static constexpr _Choice_t<_St> _Choice = _Choose<_Ty1, _Ty2>();

       public:
           // clang-format off
           template <class _Ty1, class _Ty2>
               requires (_Choice<_Ty1&, _Ty2&>._Strategy != _St::_None)
           _NODISCARD constexpr partial_ordering operator()(_Ty1&& _Left, _Ty2&& _Right) const
               noexcept(_Choice<_Ty1&, _Ty2&>._No_throw) {
               // clang-format on
               constexpr _St _Strat = _Choice<_Ty1&, _Ty2&>._Strategy;
               if constexpr (_Strat == _St::_Adl) {
                   return static_cast<partial_ordering>(/* ADL */ partial_order(_Left, _Right));
               }
               else if constexpr (_Strat == _St::_Three) {
                   return static_cast<partial_ordering>(compare_three_way{}(_Left, _Right));
               }
               else if constexpr (_Strat == _St::_Weak) {
                   return static_cast<partial_ordering>(
                       static_cast<weak_ordering>(/* ADL, throughput optimization */ weak_order(_Left, _Right)));
               }
               else if constexpr (_Strat == _St::_Strong) {
                   return static_cast<partial_ordering>(
                       static_cast<strong_ordering>(/* ADL, throughput optimization */ strong_order(_Left, _Right)));
               }
               else {
                   static_assert(_Always_false<_Ty1>, "should be unreachable");
               }
           }
       };
   } // namespace _Partial_order

   inline namespace _Cpos {
       inline constexpr _Partial_order::_Cpo partial_order;
   }
   template <class _From, class _To>
   concept _Implicitly_convertible_to = is_convertible_v<_From, _To>;

   template <class _Ty1, class _Ty2>
   concept _Can_fallback_eq_lt = requires(_Ty1 & _Left, _Ty2 & _Right) {
       { _Left == _Right } -> _Implicitly_convertible_to<bool>;
       { _Left < _Right } -> _Implicitly_convertible_to<bool>;
   };
   
   template <class _Ty1, class _Ty2>
   concept _Can_strong_order = requires(_Ty1 & _Left, _Ty2 & _Right) {
       nonstd:: strong_order(_Left, _Right);
   };

   namespace _Compare_strong_order_fallback {
       class _Cpo {
       private:
           enum class _St { _None, _Strong, _Fallback };

           template <class _Ty1, class _Ty2>
           _NODISCARD static _CONSTEVAL _Choice_t<_St> _Choose() noexcept {
               if constexpr (!same_as<decay_t<_Ty1>, decay_t<_Ty2>>) {
                   return { _St::_None };
               }
               else if constexpr (_Can_strong_order<_Ty1, _Ty2>) {
                   return { _St::_Strong, noexcept(nonstd:: strong_order(nonstd:: declval<_Ty1&>(), nonstd:: declval<_Ty2&>())) };
               }
               else if constexpr (_Can_fallback_eq_lt<_Ty1, _Ty2>) {
                   return { _St::_Fallback,
                       noexcept(nonstd:: declval<_Ty1&>() == nonstd:: declval<_Ty2&>() ? strong_ordering::equal
                                : nonstd:: declval<_Ty1&>() < nonstd:: declval<_Ty2&>() ? strong_ordering::less
                                                                                : strong_ordering::greater) };
               }
               else {
                   return { _St::_None };
               }
           }

           template <class _Ty1, class _Ty2>
           static constexpr _Choice_t<_St> _Choice = _Choose<_Ty1, _Ty2>();

       public:
           // clang-format off
           template <class _Ty1, class _Ty2>
               requires (_Choice<_Ty1&, _Ty2&>._Strategy != _St::_None)
           _NODISCARD constexpr strong_ordering operator()(_Ty1&& _Left, _Ty2&& _Right) const
               noexcept(_Choice<_Ty1&, _Ty2&>._No_throw) {
               // clang-format on
               constexpr _St _Strat = _Choice<_Ty1&, _Ty2&>._Strategy;
               if constexpr (_Strat == _St::_Strong) {
                   return nonstd:: strong_order(_Left, _Right);
               }
               else if constexpr (_Strat == _St::_Fallback) {
                   return _Left == _Right ? strong_ordering::equal
                       : _Left < _Right ? strong_ordering::less
                       : strong_ordering::greater;
               }
               else {
                   static_assert(_Always_false<_Ty1>, "should be unreachable");
               }
           }
       };
   } // namespace _Compare_strong_order_fallback

   inline namespace _Cpos {
       inline constexpr _Compare_strong_order_fallback::_Cpo compare_strong_order_fallback;
   }

   template <class _Ty1, class _Ty2>
   concept _Can_weak_order = requires(_Ty1 & _Left, _Ty2 & _Right) {
       nonstd:: weak_order(_Left, _Right);
   };

   namespace _Compare_weak_order_fallback {
       class _Cpo {
       private:
           enum class _St { _None, _Weak, _Fallback };

           template <class _Ty1, class _Ty2>
           _NODISCARD static _CONSTEVAL _Choice_t<_St> _Choose() noexcept {
               if constexpr (!same_as<decay_t<_Ty1>, decay_t<_Ty2>>) {
                   return { _St::_None };
               }
               else if constexpr (_Can_weak_order<_Ty1, _Ty2>) {
                   return { _St::_Weak, noexcept(nonstd:: weak_order(nonstd:: declval<_Ty1&>(), nonstd:: declval<_Ty2&>())) };
               }
               else if constexpr (_Can_fallback_eq_lt<_Ty1, _Ty2>) {
                   return {
                       _St::_Fallback, noexcept(nonstd:: declval<_Ty1&>() == nonstd:: declval<_Ty2&>() ? weak_ordering::equivalent
                                                : nonstd:: declval<_Ty1&>() < nonstd:: declval<_Ty2&>() ? weak_ordering::less
                                                                                                : weak_ordering::greater) };
               }
               else {
                   return { _St::_None };
               }
           }

           template <class _Ty1, class _Ty2>
           static constexpr _Choice_t<_St> _Choice = _Choose<_Ty1, _Ty2>();

       public:
           // clang-format off
           template <class _Ty1, class _Ty2>
               requires (_Choice<_Ty1&, _Ty2&>._Strategy != _St::_None)
           _NODISCARD constexpr weak_ordering operator()(_Ty1&& _Left, _Ty2&& _Right) const
               noexcept(_Choice<_Ty1&, _Ty2&>._No_throw) {
               // clang-format on
               constexpr _St _Strat = _Choice<_Ty1&, _Ty2&>._Strategy;
               if constexpr (_Strat == _St::_Weak) {
                   return nonstd:: weak_order(_Left, _Right);
               }
               else if constexpr (_Strat == _St::_Fallback) {
                   return _Left == _Right ? weak_ordering::equivalent
                       : _Left < _Right ? weak_ordering::less
                       : weak_ordering::greater;
               }
               else {
                   static_assert(_Always_false<_Ty1>, "should be unreachable");
               }
           }
       };
   } // namespace _Compare_weak_order_fallback

   inline namespace _Cpos {
       inline constexpr _Compare_weak_order_fallback::_Cpo compare_weak_order_fallback;
   }

   template <class _Ty1, class _Ty2>
   concept _Can_partial_order = requires(_Ty1 & _Left, _Ty2 & _Right) {
       nonstd:: partial_order(_Left, _Right);
   };
   
   
   namespace _Compare_partial_order_fallback {
       template <class _Ty1, class _Ty2>
       concept _Can_fallback_eq_lt_twice = requires(_Ty1 & _Left, _Ty2 & _Right) {
           { _Left == _Right } -> _Implicitly_convertible_to<bool>;
           { _Left < _Right } -> _Implicitly_convertible_to<bool>;
           { _Right < _Left } -> _Implicitly_convertible_to<bool>;
       };

       class _Cpo {
       private:
           enum class _St { _None, _Partial, _Fallback };

           template <class _Ty1, class _Ty2>
           _NODISCARD static _CONSTEVAL _Choice_t<_St> _Choose() noexcept {
               if constexpr (!same_as<decay_t<_Ty1>, decay_t<_Ty2>>) {
                   return { _St::_None };
               }
               else if constexpr (_Can_partial_order<_Ty1, _Ty2>) {
                   return { _St::_Partial, noexcept(nonstd:: partial_order(nonstd:: declval<_Ty1&>(), nonstd:: declval<_Ty2&>())) };
               }
               else if constexpr (_Can_fallback_eq_lt_twice<_Ty1, _Ty2>) {
                   return { _St::_Fallback,
                       noexcept(nonstd:: declval<_Ty1&>() == nonstd:: declval<_Ty2&>() ? partial_ordering::equivalent
                                : nonstd:: declval<_Ty1&>() < nonstd:: declval<_Ty2&>() ? partial_ordering::less
                                : nonstd:: declval<_Ty2&>() < nonstd:: declval<_Ty1&>() ? partial_ordering::greater
                                                                                : partial_ordering::unordered) };
               }
               else {
                   return { _St::_None };
               }
           }

           template <class _Ty1, class _Ty2>
           static constexpr _Choice_t<_St> _Choice = _Choose<_Ty1, _Ty2>();

       public:
           // clang-format off
           template <class _Ty1, class _Ty2>
               requires (_Choice<_Ty1&, _Ty2&>._Strategy != _St::_None)
           _NODISCARD constexpr partial_ordering operator()(_Ty1&& _Left, _Ty2&& _Right) const
               noexcept(_Choice<_Ty1&, _Ty2&>._No_throw) {
               // clang-format on
               constexpr _St _Strat = _Choice<_Ty1&, _Ty2&>._Strategy;
               if constexpr (_Strat == _St::_Partial) {
                   return nonstd:: partial_order(_Left, _Right);
               }
               else if constexpr (_Strat == _St::_Fallback) {
                   return _Left == _Right ? partial_ordering::equivalent
                       : _Left < _Right ? partial_ordering::less
                       : _Right < _Left ? partial_ordering::greater
                       : partial_ordering::unordered;
               }
               else {
                   static_assert(_Always_false<_Ty1>, "should be unreachable");
               }
           }
       };
   } // namespace _Compare_partial_order_fallback

   inline namespace _Cpos {
       inline constexpr _Compare_partial_order_fallback::_Cpo compare_partial_order_fallback;
   }



}